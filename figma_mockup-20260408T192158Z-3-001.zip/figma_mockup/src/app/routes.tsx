import { createBrowserRouter } from "react-router";
import { Dashboard } from "./pages/Dashboard";
import { Scheduler } from "./pages/Scheduler";
import { CreatePost } from "./pages/CreatePost";
import { Accounts } from "./pages/Accounts";
import { Analytics } from "./pages/Analytics";
import { Layout } from "./components/Layout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "scheduler", Component: Scheduler },
      { path: "create", Component: CreatePost },
      { path: "accounts", Component: Accounts },
      { path: "analytics", Component: Analytics },
    ],
  },
]);
