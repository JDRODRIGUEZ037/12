import { useState } from "react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Calendar } from "../components/ui/calendar";
import { Badge } from "../components/ui/badge";
import { 
  Instagram, 
  Twitter, 
  Facebook, 
  Linkedin,
  Clock,
  Edit,
  Trash2
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const scheduledPosts = [
  {
    id: 1,
    date: new Date(2026, 2, 20, 10, 0),
    platform: "Instagram",
    icon: Instagram,
    color: "bg-pink-100 text-pink-700",
    content: "Nueva colección primavera-verano 2026 🌸",
    status: "scheduled"
  },
  {
    id: 2,
    date: new Date(2026, 2, 20, 14, 30),
    platform: "Twitter",
    icon: Twitter,
    color: "bg-blue-100 text-blue-700",
    content: "Consejos para aumentar tu engagement en redes sociales",
    status: "scheduled"
  },
  {
    id: 3,
    date: new Date(2026, 2, 21, 9, 0),
    platform: "Facebook",
    icon: Facebook,
    color: "bg-indigo-100 text-indigo-700",
    content: "Evento en vivo este fin de semana 🎉",
    status: "scheduled"
  },
  {
    id: 4,
    date: new Date(2026, 2, 21, 16, 0),
    platform: "LinkedIn",
    icon: Linkedin,
    color: "bg-sky-100 text-sky-700",
    content: "El futuro del marketing digital en 2026",
    status: "scheduled"
  },
  {
    id: 5,
    date: new Date(2026, 2, 22, 11, 0),
    platform: "Instagram",
    icon: Instagram,
    color: "bg-pink-100 text-pink-700",
    content: "Behind the scenes de nuestra última campaña",
    status: "scheduled"
  },
];

export function Scheduler() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date(2026, 2, 20));

  const postsForSelectedDate = scheduledPosts.filter(post => {
    if (!selectedDate) return false;
    return format(post.date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd');
  });

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Programador de Posts</h1>
          <p className="text-gray-600 mt-1">Gestiona y programa tus publicaciones</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Clock className="w-4 h-4 mr-2" />
          Nueva Programación
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card className="p-6 lg:col-span-1">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Calendario</h2>
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            locale={es}
            className="rounded-md border"
          />
          
          <div className="mt-6 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Posts programados</span>
              <Badge variant="secondary">{scheduledPosts.length}</Badge>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Este mes</span>
              <Badge variant="secondary">{scheduledPosts.length}</Badge>
            </div>
          </div>
        </Card>

        {/* Scheduled Posts List */}
        <Card className="p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Posts para {selectedDate ? format(selectedDate, "d 'de' MMMM, yyyy", { locale: es }) : "seleccionar fecha"}
          </h2>
          
          {postsForSelectedDate.length > 0 ? (
            <div className="space-y-4">
              {postsForSelectedDate.map((post) => (
                <div key={post.id} className="flex items-start gap-4 p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors">
                  <div className={`p-3 rounded-lg ${post.color}`}>
                    <post.icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-gray-900">{post.platform}</span>
                      <Badge variant="outline" className="text-xs">
                        {format(post.date, "HH:mm")}
                      </Badge>
                    </div>
                    <p className="text-gray-700">{post.content}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Clock className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">No hay posts programados para esta fecha</p>
              <Button variant="outline" className="mt-4">
                Programar Post
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* Timeline View */}
      <Card className="p-6 mt-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-6">Próximas Publicaciones</h2>
        <div className="space-y-6">
          {scheduledPosts.slice(0, 5).map((post, index) => (
            <div key={post.id} className="flex items-start gap-4">
              <div className="flex flex-col items-center">
                <div className={`p-2 rounded-lg ${post.color}`}>
                  <post.icon className="w-4 h-4" />
                </div>
                {index < scheduledPosts.length - 1 && (
                  <div className="w-px h-12 bg-gray-200 my-2" />
                )}
              </div>
              <div className="flex-1 pb-6">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium text-gray-900">
                    {format(post.date, "d 'de' MMMM, yyyy", { locale: es })}
                  </span>
                  <span className="text-sm text-gray-500">
                    {format(post.date, "HH:mm")}
                  </span>
                </div>
                <p className="text-sm text-gray-700">{post.content}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
