import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { 
  Instagram, 
  Twitter, 
  Facebook, 
  Linkedin,
  Plus,
  Settings,
  TrendingUp,
  Users
} from "lucide-react";

const accounts = [
  {
    id: 1,
    platform: "Instagram",
    icon: Instagram,
    username: "@mi_empresa",
    followers: "18.5K",
    engagement: "8.4%",
    status: "connected",
    color: "bg-pink-500"
  },
  {
    id: 2,
    platform: "Twitter",
    icon: Twitter,
    username: "@mi_empresa",
    followers: "12.3K",
    engagement: "6.2%",
    status: "connected",
    color: "bg-blue-400"
  },
  {
    id: 3,
    platform: "Facebook",
    icon: Facebook,
    username: "Mi Empresa",
    followers: "24.1K",
    engagement: "5.8%",
    status: "connected",
    color: "bg-blue-600"
  },
  {
    id: 4,
    platform: "LinkedIn",
    icon: Linkedin,
    username: "Mi Empresa",
    followers: "8.7K",
    engagement: "4.3%",
    status: "connected",
    color: "bg-blue-700"
  },
];

export function Accounts() {
  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Cuentas Conectadas</h1>
          <p className="text-gray-600 mt-1">Gestiona tus perfiles de redes sociales</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Conectar Cuenta
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Cuentas</p>
              <p className="text-3xl font-bold text-gray-900">{accounts.length}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Seguidores Totales</p>
              <p className="text-3xl font-bold text-gray-900">63.6K</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Engagement Promedio</p>
              <p className="text-3xl font-bold text-gray-900">6.2%</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Accounts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {accounts.map((account) => (
          <Card key={account.id} className="p-6">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className={`${account.color} p-4 rounded-lg`}>
                  <account.icon className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{account.platform}</h3>
                  <p className="text-gray-600">{account.username}</p>
                </div>
              </div>
              <Badge variant="secondary" className="bg-green-100 text-green-700 border-green-200">
                Conectada
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Seguidores</p>
                <p className="text-xl font-bold text-gray-900">{account.followers}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Engagement</p>
                <p className="text-xl font-bold text-gray-900">{account.engagement}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="outline" className="flex-1">
                <Settings className="w-4 h-4 mr-2" />
                Configurar
              </Button>
              <Button variant="outline" className="flex-1">
                Ver Detalles
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {/* Add New Account Card */}
      <Card className="p-8 mt-6 border-2 border-dashed border-gray-300 hover:border-blue-400 transition-colors">
        <div className="text-center">
          <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-8 h-8 text-gray-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Conectar Nueva Cuenta
          </h3>
          <p className="text-gray-600 mb-4">
            Agrega más perfiles de redes sociales para gestionar todo en un solo lugar
          </p>
          <Button className="bg-blue-600 hover:bg-blue-700">
            Conectar Cuenta
          </Button>
        </div>
      </Card>
    </div>
  );
}
