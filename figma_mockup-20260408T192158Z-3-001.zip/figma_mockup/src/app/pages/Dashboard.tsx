import { Card } from "../components/ui/card";
import { 
  TrendingUp, 
  Users, 
  MessageCircle, 
  Heart,
  Instagram,
  Twitter,
  Facebook,
  Linkedin
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

const statsData = [
  { label: "Seguidores Totales", value: "47,321", change: "+12.5%", icon: Users, color: "bg-blue-500" },
  { label: "Engagement Rate", value: "8.4%", change: "+2.3%", icon: Heart, color: "bg-pink-500" },
  { label: "Posts Publicados", value: "124", change: "+18", icon: MessageCircle, color: "bg-green-500" },
  { label: "Alcance Total", value: "328K", change: "+24.1%", icon: TrendingUp, color: "bg-purple-500" },
];

const engagementData = [
  { name: "Lun", engagement: 4200 },
  { name: "Mar", engagement: 5800 },
  { name: "Mié", engagement: 4900 },
  { name: "Jue", engagement: 7200 },
  { name: "Vie", engagement: 6500 },
  { name: "Sáb", engagement: 8900 },
  { name: "Dom", engagement: 7800 },
];

const platformData = [
  { name: "Instagram", value: 45, color: "#E1306C" },
  { name: "Twitter", value: 25, color: "#1DA1F2" },
  { name: "Facebook", value: 20, color: "#4267B2" },
  { name: "LinkedIn", value: 10, color: "#0077B5" },
];

const recentPosts = [
  { 
    id: 1, 
    platform: "Instagram", 
    icon: Instagram, 
    content: "Lanzamiento de nueva campaña de verano 🌞", 
    likes: 1234, 
    comments: 89,
    time: "Hace 2 horas"
  },
  { 
    id: 2, 
    platform: "Twitter", 
    icon: Twitter, 
    content: "Tips para mejorar tu estrategia de contenido", 
    likes: 567, 
    comments: 34,
    time: "Hace 5 horas"
  },
  { 
    id: 3, 
    platform: "Facebook", 
    icon: Facebook, 
    content: "Evento especial este fin de semana 🎉", 
    likes: 892, 
    comments: 45,
    time: "Hace 1 día"
  },
  { 
    id: 4, 
    platform: "LinkedIn", 
    icon: Linkedin, 
    content: "Casos de éxito en marketing digital", 
    likes: 234, 
    comments: 12,
    time: "Hace 1 día"
  },
];

export function Dashboard() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-1">Resumen de tu actividad en redes sociales</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statsData.map((stat, index) => (
          <Card key={index} className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-green-600 mt-2">{stat.change} vs mes anterior</p>
              </div>
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Engagement Chart */}
        <Card className="p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Engagement Semanal</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={engagementData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip 
                contentStyle={{ backgroundColor: 'white', border: '1px solid #e5e7eb', borderRadius: '8px' }}
              />
              <Line 
                type="monotone" 
                dataKey="engagement" 
                stroke="#3b82f6" 
                strokeWidth={2}
                dot={{ fill: '#3b82f6', r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Platform Distribution */}
        <Card className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Distribución por Plataforma</h2>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={platformData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {platformData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {platformData.map((platform, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: platform.color }}
                  />
                  <span className="text-sm text-gray-700">{platform.name}</span>
                </div>
                <span className="text-sm font-semibold text-gray-900">{platform.value}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Posts */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Posts Recientes</h2>
        <div className="space-y-4">
          {recentPosts.map((post) => (
            <div key={post.id} className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 transition-colors">
              <div className="p-2 bg-gray-100 rounded-lg">
                <post.icon className="w-5 h-5 text-gray-700" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium text-gray-900">{post.platform}</span>
                  <span className="text-sm text-gray-500">• {post.time}</span>
                </div>
                <p className="text-gray-700 mb-2">{post.content}</p>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    {post.likes}
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4" />
                    {post.comments}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
